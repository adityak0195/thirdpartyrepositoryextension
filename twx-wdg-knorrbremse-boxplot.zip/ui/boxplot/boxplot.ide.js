TW.IDE.Widgets.boxplot = function () {

	this.MAX_INPUTS = 10;
    this.DEFAULT_INPUTS = 1;

    this.DataTypeOptions = [
        { value: 'BOOLEAN', text: 'BOOLEAN' },
        { value: 'DATETIME', text: 'DATETIME' },
        { value: 'IMAGE', text: 'IMAGE' },
        { value: 'INTEGER', text: 'INTEGER' },
        { value: 'LOCATION', text: 'LOCATION' },
        { value: 'LONG', text: 'LONG' },
        { value: 'NUMBER', text: 'NUMBER' },
        { value: 'QUERY', text: 'QUERY' },
        { value: 'TAGS', text: 'TAGS' },
        { value: 'STRING', text: 'STRING', defaultValue: true }
	];
	
	this.widgetIconUrl = function() {
		return  "'../Common/extensions/twx-wdg-knorrbremse-boxplot/ui/boxplot/boxplot.ide.png'";
	};

	this.widgetProperties = function () {
		var properties = {
			'name': 'Boxplot',
			'description': 'Boxplot-Widget',
            'category': ['Common'],
            'supportsAutoResize': true,
            'supportsTooltip': true,            
			'properties': {
				'Title':{
					'isBindingTarget': true,
                    'isEditable': true,
                    'defaultValue': 'Boxplot',
                    'baseType': 'STRING',
				},
				'NumberOfSeries': {
                    'baseType': 'NUMBER',
                    'defaultValue': this.DEFAULT_INPUTS
                },
				'Data': {
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'FrameStyle': {
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultChartStyle' 
                },
                'Orientation': {
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': 'vertical',                 
                    'selectOptions': [
                        { value: 'vertical', text: 'Vertical' },
                        { value: 'horizontal', text: 'Horizontal' }                        
                    ]
                },
                'BoxplotStyling': {
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': false,                 
                    'selectOptions': [
                        { value: false, text: 'Standard' },
                        { value: true, text: 'Only Mean' },                        
                        { value: 'sd', text: 'Mean and Standard Deviation' }                       
                    ]
                },
                'ShowLegend': {
                    'baseType': 'BOOLEAN',
                    'isVisible': true,
                    'defaultValue': true
                },
                'Width': {
                    'defaultValue': 480,
                },
                'Height': {
					'defaultValue': 240,
				},
			}
		}

		var seriesNumber;
        for (seriesNumber = 1; seriesNumber <= this.DEFAULT_INPUTS; seriesNumber++) {
            var seriesStyle = {
                'baseType': 'STYLEDEFINITION',
				'isVisible': true,
				'defaultValue': 'DefaultChartStyle'+seriesNumber
			};
			var seriesLabel = {
                'isBindingTarget': true,
                'baseType': 'STRING',
                'isVisible': true
            };
            var seriesDataFieldName = {
                'baseType': 'FIELDNAME',
                'isBindingTarget':false,
                'sourcePropertyName': 'Data',
                'baseTypeRestriction': 'NUMBER',
                'isVisible': true,        
            };
			properties.properties['SeriesStyle' + seriesNumber] = seriesStyle;
            properties.properties['SeriesLabel' + seriesNumber] = seriesLabel;
            properties.properties['SeriesDataValueField' + seriesNumber] = seriesDataFieldName;            					
        }

        for (seriesNumber = this.DEFAULT_INPUTS + 1; seriesNumber <= this.MAX_INPUTS; seriesNumber++) {
            var seriesStyle = {
                'baseType': 'STYLEDEFINITION',
				'isVisible': false,
				'defaultValue': 'DefaultChartStyle'+seriesNumber				
			};
			var seriesLabel = {
                'isBindingTarget': false,
                'baseType': 'STRING',
                'isVisible': false
            };
            var seriesDataFieldName = {
                'baseType': 'FIELDNAME',
                'isBindingTarget':false,
                'sourcePropertyName': 'Data',
                'baseTypeRestriction': 'NUMBER',
                'isVisible': false,        
            };
			properties.properties['SeriesStyle' + seriesNumber] = seriesStyle;
            properties.properties['SeriesLabel' + seriesNumber] = seriesLabel;					
            properties.properties['SeriesDataValueField' + seriesNumber] = seriesDataFieldName;	
        }
		return properties;
    };
    
 

	this.setInputsProperties = function (value) {
        var allWidgetProps = this.allWidgetProperties();
        var seriesNumber;

        for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
            allWidgetProps.properties['SeriesStyle' + seriesNumber].isVisible = true;
			allWidgetProps.properties['SeriesStyle' + seriesNumber].baseType = 'STYLEDEFINITION';
			allWidgetProps.properties['SeriesStyle' + seriesNumber].defaultValue = "DefaultChartStyle"+seriesNumber;
			
			allWidgetProps.properties['SeriesLabel' + seriesNumber].isVisible = true;
            allWidgetProps.properties['SeriesLabel' + seriesNumber].isBindingTarget = true;
            allWidgetProps.properties['SeriesLabel' + seriesNumber].baseType = 'STRING';

            allWidgetProps.properties['SeriesDataValueField' + seriesNumber].isVisible = true;
            allWidgetProps.properties['SeriesDataValueField' + seriesNumber].isBindingTarget = false;
            allWidgetProps.properties['SeriesDataValueField' + seriesNumber].baseType = 'FIELDNAME';
        }

        for (seriesNumber = value + 1; seriesNumber <= this.MAX_INPUTS; seriesNumber++) {
            allWidgetProps.properties['SeriesStyle' + seriesNumber].isVisible = false;
			
			allWidgetProps.properties['SeriesLabel' + seriesNumber].isVisible = false;
            allWidgetProps.properties['SeriesLabel' + seriesNumber].isBindingTarget = false;


            allWidgetProps.properties['SeriesDataValueField' + seriesNumber].isVisible = false;
        }
    };

	this.afterLoad = function () {
        this.setInputsProperties(this.getProperty('NumberOfSeries'));
    };

	this.beforeSetProperty = function (name, value) {
        if (name === 'NumberOfSeries') {
            value = parseInt(value, 10);
            if (value <= 0 || value > this.MAX_INPUTS) {
                return TW.IDE.I18NController.translate('tw.eventsrouter-ide.number-of-inputs-warning') + this.MAX_INPUTS;
            }
        }
    };

	this.afterSetProperty = function (name, value) {
		if (name === 'NumberOfSeries') {
            this.setInputsProperties(value);
        }
        this.updatedProperties();
        return true;
	};
    
    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-boxplot"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span>'+"Boxplot"+'</span></td></tr></table></div>';
        return html;
    };

	this.afterRender = function () {
		valueElem = this.jqElement.find('.widget-boxplot-title');
		valueElem.text(this.getProperty('Title'));
    };
    
    this.renderFrame = function(){
        var style = TW.getStyleFromStyleDefinition(this.getProperty('FrameStyle'));
        var borderStyle = style.lineStyle;
        var bordeWidth = style.lineThickness;
        var borderColor = style.foregroundColor;
        return 'style="' +
            'border-style:'+ borderStyle +
            'border-width:' + bordeWidth +
            'border-color:' + borderColor + '";'
    };
};