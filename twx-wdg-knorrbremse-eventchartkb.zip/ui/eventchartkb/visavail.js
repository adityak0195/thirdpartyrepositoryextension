function visavailChart() {
  // define chart layout
  var margin = {
    // top margin includes title and legend
    top: 0,

    // right margin should provide space for last horz. axis title
    right: 40,

    bottom: 40,

    // left margin should provide space for y axis titles
    left: 0,
  };

  var marginSubTitle = 0;

  var marginLabelTop = 20;

  // height of horizontal data bars
  var dataHeight = 18;

  // spacing between horizontal data bars
  var lineSpacing = 10;

  // vertical space for heading
  var paddingTopHeading = -40;

  // vertical overhang of vertical grid lines on bottom
  var paddingBottom = 10;

  // space for y axis titles
  var paddingLeft = 0;

  var height = 0;

  var width = 940 - margin.left - margin.right;

  // title of chart is drawn or not (default: yes)
  var drawTitle = 1;

  // subtitle of chart is drawn or not (default: yes)
  var drawSubTitle = 1;

  // title of chart is drawn or not (default: bottom)
  var label = null;

  // year ticks to be emphasized or not (default: yes)
  var emphasizeYearTicks = 1;

  // ticksFormat (0: automatic)
  var ticksFormat = 0;

  // ticks (0: automatic)
  var ticks = 0;

  // define chart pagination
  // max. no. of datasets that is displayed, 0: all (default: all)
  var maxDisplayDatasets = 0;

  // dataset that is displayed first in the current
  // display, chart will show datasets "curDisplayFirstDataset" to
  // "curDisplayFirstDataset+maxDisplayDatasets"
  var curDisplayFirstDataset = 0;

  // range of dates that will be shown
  // if from-date (1st element) or to-date (2nd element) is zero,
  // it will be determined according to your data (default: automatically)
  var displayDateRange = [0, 0];

  var id = null;

  // global div for tooltip
  var div = d3.select('body').append('div')
    .attr('class', 'kbtooltip')
    .style('opacity', 0);

  var definedBlocks = null;
  var customCategories = null;
  var isDateOnlyFormat = null;

  function chart(selection) {

    if (!Array.prototype.find) {
      Object.defineProperty(Array.prototype, 'find', {
        value: function (predicate) {
          // 1. Let O be ? ToObject(this value).
          if (this == null) {
            throw new TypeError('"this" is null or not defined');
          }

          var o = Object(this);

          // 2. Let len be ? ToLength(? Get(O, "length")).
          var len = o.length >>> 0;

          // 3. If IsCallable(predicate) is false, throw a TypeError exception.
          if (typeof predicate !== 'function') {
            throw new TypeError('predicate must be a function');
          }

          // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
          var thisArg = arguments[1];

          // 5. Let k be 0.
          var k = 0;

          // 6. Repeat, while k < len
          while (k < len) {
            // a. Let Pk be ! ToString(k).
            // b. Let kValue be ? Get(O, Pk).
            // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
            // d. If testResult is true, return kValue.
            var kValue = o[k];
            if (predicate.call(thisArg, kValue, k, o)) {
              return kValue;
            }
            // e. Increase k by 1.
            k++;
          }

          // 7. Return undefined.
          return undefined;
        }
      });
    }

    selection.each(function drawGraph(dataset) {
      // check which subset of datasets have to be displayed
      var maxPages = 0;
      var startSet;
      var endSet;
      if (maxDisplayDatasets !== 0) {
        startSet = curDisplayFirstDataset;
        if (curDisplayFirstDataset + maxDisplayDatasets > dataset.length) {
          endSet = dataset.length;
        } else {
          endSet = curDisplayFirstDataset + maxDisplayDatasets;
        }
        maxPages = Math.ceil(dataset.length / maxDisplayDatasets);
      } else {
        startSet = 0;
        endSet = dataset.length;
      }

      // append data attribute in HTML for pagination interface
      selection.attr('data-max-pages', maxPages);

      var noOfDatasets = endSet - startSet;

      // check how data is arranged
      if (definedBlocks === null) {
        definedBlocks = 0;
        for (var i = 0; i < dataset.length; i++) {
          if (dataset[i].data[0].length === 3) {
            definedBlocks = 1;
            break;
          } else {
            if (definedBlocks) {
              throw new Error('Detected different data formats in input data. Format can either be ' +
                'continuous data format or time gap data format but not both.');
            }
          }
        }
      }

      // check if data has custom categories
      if (customCategories === null) {
        customCategories = 0;
        for (var i = 0; i < dataset.length; i++) {
          if (dataset[i].data[0][1] != 0 && dataset[i].data[0][1] != 1) {
            customCategories = 1;
            break;
          }
        }
      }

      //TODO Hardcoded that we always want Custom Categories
      customCategories = 1

      // parse data text strings to JavaScript date stamps
      var parseDate = d3.time.format('%Y-%m-%d');
      var parseDateTime = d3.time.format('%Y-%m-%d %H:%M:%S');
      var parseDateRegEx = new RegExp(/^\d{4}-\d{2}-\d{2}$/);
      var parseDateTimeRegEx = new RegExp(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
      if (isDateOnlyFormat === null) {
        isDateOnlyFormat = false;
      }
      dataset.forEach(function (d) {
        d.data.forEach(function (d1) {
          if (!(d1[0] instanceof Date)) {
            if (parseDateRegEx.test(d1[0])) {
              // d1[0] is date without time data
              d1[0] = parseDate.parse(d1[0]);
            } else if (parseDateTimeRegEx.test(d1[0])) {
              // d1[0] is date with time data
              d1[0] = parseDateTime.parse(d1[0]);
              isDateOnlyFormat = false;
            } else {
              throw new Error('Date/time format not recognized. Pick between \'YYYY-MM-DD\' or ' +
                '\'YYYY-MM-DD HH:MM:SS\'.');
            }

            if (!definedBlocks) {
              d1[2] = d3.time.second.offset(d1[0], d.interval_s);
            } else {
              if (parseDateRegEx.test(d1[2])) {
                // d1[2] is date without time data
                d1[2] = parseDate.parse(d1[2]);
              } else if (parseDateTimeRegEx.test(d1[2])) {
                // d1[2] is date with time data
                d1[2] = parseDateTime.parse(d1[2]);
              } else {
                throw new Error('Date/time format not recognized. Pick between \'YYYY-MM-DD\' or ' +
                  '\'YYYY-MM-DD HH:MM:SS\'.');
              }
            }
          }
        });
      });

      // cluster data by dates to form time blocks
      dataset.forEach(function (series, seriesI) {
        var tmpData = [];
        var dataLength = series.data.length;
        series.data.forEach(function (d, i) {
          if (i !== 0 && i < dataLength) {
            if (d[1] === tmpData[tmpData.length - 1][1]) {
              // the value has not changed since the last date
              if (definedBlocks) {
                if (tmpData[tmpData.length - 1][2].getTime() === d[0].getTime()) {
                  // end of old and start of new block are the same
                  tmpData[tmpData.length - 1][2] = d[2];
                  tmpData[tmpData.length - 1][3] = 1;
                } else {
                  tmpData.push(d);
                }
              } else {
                tmpData[tmpData.length - 1][2] = d[2];
                tmpData[tmpData.length - 1][3] = 1;
              }
            } else {
              // the value has changed since the last date
              d[3] = 0;
              if (!definedBlocks) {
                // extend last block until new block starts
                tmpData[tmpData.length - 1][2] = d[0];
              }
              tmpData.push(d);
            }
          } else if (i === 0) {
            d[3] = 0;
            tmpData.push(d);
          }
        });
        dataset[seriesI].disp_data = tmpData;
      });

      // determine start and end dates among all nested datasets
      var startDate = displayDateRange[0];
      var endDate = displayDateRange[1];

      dataset.forEach(function (series, seriesI) {
        if (series.disp_data.length > 0) {
          if (startDate === 0) {
            startDate = series.disp_data[0][0];
            endDate = series.disp_data[series.disp_data.length - 1][2];
          } else {
            if (displayDateRange[0] === 0 && series.disp_data[0][0] < startDate) {
              startDate = series.disp_data[0][0];
            }
            if (displayDateRange[1] === 0 && series.disp_data[series.disp_data.length - 1][2] > endDate) {
              endDate = series.disp_data[series.disp_data.length - 1][2];
            }
          }
        }
      });

      // define scales
      var xScale = d3.time.scale()
        .domain([startDate, endDate])
        .range([0, width])
        .clamp(1);

      // define axes
      var xAxis = d3.svg.axis()
        .scale(xScale)
        .orient('top');

      if (ticksFormat && ticks) {
        var xAxis = d3.svg.axis()
          .scale(xScale)
          .orient('top')
          .ticks(ticks)
          .tickFormat(d3.time.format(ticksFormat));
      }

      if (drawTitle)
        margin.top = 20;

      if (drawSubTitle)
        marginSubTitle = 10;

      var labelPos = 5;
      if (label != 'top') {
        labelPos = dataHeight * noOfDatasets + lineSpacing * noOfDatasets - 1 + paddingBottom + 18;
        marginLabelTop = 0;
      }

      // create SVG element
      var svg = d3.select(id).append('svg')
        .attr('width', width)
        .attr('height', height)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + 0 + ')');

      // create basic element groups
      svg.append('g').attr('id', 'g_title').attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');
      svg.append('g').attr('id', 'g_axis').attr('transform', 'translate(' + margin.left + ',' + (margin.top + marginSubTitle + marginLabelTop) + ')');
      svg.append('g').attr('id', 'g_data').attr('transform', 'translate(' + margin.left + ',' + (margin.top + marginSubTitle + marginLabelTop) + ')');

      // create y axis labels
      if (label != 'none') {
        var labels = svg.select('#g_axis').selectAll('text')
          .data(dataset.slice(startSet, endSet))
          .enter();

        // text labels
        labels.append('text')
          .attr('x', paddingLeft)
          .attr('y', lineSpacing + dataHeight / 2)
          .text(function (d) {
            if (!(d.measure_html != null)) {
              return d.measure;
            }
          })
          .attr('transform', function (d, i) {
            return 'translate(0,' + ((lineSpacing + dataHeight) * i) + ')';
          })
          .attr('class', function (d) {
            var returnCSSClass = 'kbytitle';
            if (d.measure_url != null) {
              returnCSSClass = returnCSSClass + ' link';
            }
            return returnCSSClass;
          })
          .on('click', function (d) {
            if (d.measure_url != null) {
              return window.open(d.measure_url);
            }
            return null;
          });

        // HTML labels
        labels.append('foreignObject')
          .attr('x', paddingLeft)
          .attr('y', lineSpacing)
          .attr('transform', function (d, i) {
            return 'translate(0,' + ((lineSpacing + dataHeight) * i) + ')';
          })
          .attr('width', -1 * paddingLeft)
          .attr('height', dataHeight)
          .attr('class', 'kbytitle')
          .html(function (d) {
            if (d.measure_html != null) {
              return d.measure_html;
            }
          });
      }
      // create vertical grid
      svg.select('#g_axis').selectAll('line.kbvert_grid').data(xScale.ticks())
        .enter()
        .append('line')
        .attr({
          'class': 'kbvert_grid',
          'x1': function (d) {
            return xScale(d);
          },
          'x2': function (d) {
            return xScale(d);
          },
          'y1': 0,
          'y2': dataHeight * noOfDatasets + lineSpacing * noOfDatasets - 1 + paddingBottom
        });

      // create horizontal grid
      svg.select('#g_axis').selectAll('line.kbhorz_grid').data(dataset)
        .enter()
        .append('line')
        .attr({
          'class': 'kbhorz_grid',
          'x1': 0,
          'x2': width,
          'y1': function (d, i) {
            return ((lineSpacing + dataHeight) * i) + lineSpacing + dataHeight / 2;
          },
          'y2': function (d, i) {
            return ((lineSpacing + dataHeight) * i) + lineSpacing + dataHeight / 2;
          }
        });

      // create x axis
      if (label != 'none')
        svg.select('#g_axis').append('g')
          .attr('class', 'kbaxis')
          .attr("transform", "translate(0," + labelPos + ")")
          .call(xAxis);

      // make y groups for different data series
      var g = svg.select('#g_data').selectAll('.g_data')
        .data(dataset.slice(startSet, endSet))
        .enter()
        .append('g')
        .attr('transform', function (d, i) {
          return 'translate(0,' + ((lineSpacing + dataHeight) * i) + ')';
        })
        .attr('class', 'dataset');

      // add data series
      g.selectAll('rect')
        .data(function (d) {
          return d.disp_data;
        })
        .enter()
        .append('rect')
        .attr('x', function (d) {
          return xScale(d[0]);
        })
        .attr('y', lineSpacing)
        .attr('width', function (d) {
          return (xScale(d[2]) - xScale(d[0]));
        })
        .attr('height', dataHeight)
        .attr('class', function (d) {
          if (customCategories) {
            var series = dataset.find(
              function (series) {
                return series.disp_data.indexOf(d) >= 0;
              }
            );
            if (series && series.categories) {
              d3.select(this).attr('fill', series.categories[d[1]].color);
              return '';
            }
          } else {
            if (d[1] === 1) {
              // data available
              return 'kbrect_has_data';
            } else {
              // no data available
              return 'kbrect_has_no_data';
            }
          }
        })
        .on('mouseover', function (d, i) {
          var matrix = this.getScreenCTM().translate(+this.getAttribute('x'), +this.getAttribute('y'));
          div.transition()
            .duration(200)
            .style('opacity', 0.9);
          div.html(function () {
            var output = '';
            if (customCategories) {
              // custom categories: display category name
              output = '&nbsp;' + d[1] + '&nbsp;';
            } else {
              if (d[1] === 1) {
                // checkmark icon
                output = '<i class="fa fa-fw fa-check kbtooltip_has_data"></i>';
              } else {
                // cross icon
                output = '<i class="fa fa-fw fa-times kbtooltip_has_no_data"></i>';
              }
            }
            if (isDateOnlyFormat) {
              if (d[2] > d3.time.second.offset(d[0], 86400)) {
                return output + moment(parseDate(d[0])).format('l')
                  + ' - ' + moment(parseDate(d[2])).format('l');
              }
              return output + moment(parseDate(d[0])).format('l');
            } else {
              if (d[2] > d3.time.second.offset(d[0], 86400)) {
                return output + moment(parseDateTime(d[0])).format('l') + ' '
                  + moment(parseDateTime(d[0])).format('H:mm:ss A') + ' - '
                  + moment(parseDateTime(d[2])).format('l') + ' '
                  + moment(parseDateTime(d[2])).format('H:mm:ss A');
              }
              return output + moment(parseDateTime(d[0])).format('H:mm:ss A') + ' - '
                + moment(parseDateTime(d[2])).format('H:mm:ss A');
            }
          })
            .style('left', function () {
              return window.pageXOffset + matrix.e + 'px';
            })
            .style('top', function () {
              return window.pageYOffset + matrix.f - 11 + 'px';
            })
            .style('height', dataHeight + 11 + 'px');
        })
        .on('mouseout', function () {
          div.transition()
            .duration(500)
            .style('opacity', 0);
        });

      // rework ticks and grid for better visual structure
      function isYear(t) {
        return +t === +(new Date(t.getFullYear(), 0, 1, 0, 0, 0));
      }

      function isMonth(t) {
        return +t === +(new Date(t.getFullYear(), t.getMonth(), 1, 0, 0, 0));
      }

      var xTicks = xScale.ticks();
      var isYearTick = xTicks.map(isYear);
      var isMonthTick = xTicks.map(isMonth);
      // year emphasis
      // ensure year emphasis is only active if years are the biggest clustering unit
      if (emphasizeYearTicks
        && !(isYearTick.every(function (d) { return d === true; }))
        && isMonthTick.every(function (d) { return d === true; })) {
        d3.select(this).selectAll('g.tick').each(function (d, i) {
          if (isYearTick[i]) {
            d3.select(this)
              .attr({
                'class': 'kbx_tick_emph',
              });
          }
        });
        d3.select(this).selectAll('.kbvert_grid').each(function (d, i) {
          if (isYearTick[i]) {
            d3.select(this)
              .attr({
                'class': 'kbvert_grid_emph',
              });
          }
        });
      }

      // create title
      if (drawTitle) {
        svg.select('#g_title')
          .append('text')
          .attr('x', paddingLeft)
          .attr('y', -5)
          .text(drawTitle)
          .attr('class', 'kbheading');
      }

      if (drawSubTitle) {
        // create subtitle
        var subtitleText = 'from ' + moment(startDate).format(drawSubTitle) + ' to '
            + moment(endDate).format(drawSubTitle);
        svg.select('#g_title')
          .append('text')
          .attr('x', paddingLeft)
          .attr('y', 10)
          .text(subtitleText)
          .attr('class', 'kbsubheading');
      }
    });
  }

  chart.width = function (_) {
    if (!arguments.length) return width;
    width = _;
    return chart;
  };

  chart.height = function (_) {
    if (!arguments.length) return height;
    height = _;
    return chart;
  };

  chart.drawTitle = function (_) {
    if (!arguments.length) return drawTitle;
    drawTitle = _;
    return chart;
  };

  chart.drawSubTitle = function (_) {
    if (!arguments.length) return drawSubTitle;
    drawSubTitle = _;
    return chart;
  };

  chart.maxDisplayDatasets = function (_) {
    if (!arguments.length) return maxDisplayDatasets;
    maxDisplayDatasets = _;
    return chart;
  };

  chart.curDisplayFirstDataset = function (_) {
    if (!arguments.length) return curDisplayFirstDataset;
    curDisplayFirstDataset = _;
    return chart;
  };

  chart.displayDateRange = function (_) {
    if (!arguments.length) return displayDateRange;
    displayDateRange = _;
    return chart;
  };

  chart.emphasizeYearTicks = function (_) {
    if (!arguments.length) return emphasizeYearTicks;
    emphasizeYearTicks = _;
    return chart;
  };

  chart.setTicksFormat = function (_) {
    if (!arguments.length) return ticksFormat;
    ticksFormat = _;
    return chart;
  };

  chart.setTicks = function (_) {
    if (!arguments.length) return ticks;
    ticks = _;
    return chart;
  };

  chart.setBarHeight = function (_) {
    if (!arguments.length) return dataHeight;
    dataHeight = _;
    return chart;
  };

  chart.labelBottom = function (_) {
    if (!arguments.length) return label;
    label = _;
    return chart;
  };

  chart.setID = function (_) {
    if (!arguments.length) return id;
    id = _;
    return chart;
  };

  return chart;
}
