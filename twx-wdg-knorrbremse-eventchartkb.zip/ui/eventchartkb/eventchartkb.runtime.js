TW.Runtime.Widgets.eventchartkb= function () {
	var rawData = [];
	var uniqueCategories = [];
	var dataset = [];

	var timeFieldName;
	var eventFieldName;
	var idNumber;

	var startDate;
	var endDate;

	var pWidth = this.getProperty('Width');


	this.updateEventchartElementId = function () {
		var id = this.getProperty('Id');
		var elem = document.getElementById('eventchartkb'+id);
		while (elem != null) {
			var idVal = id.split("-");
			var idNumber = parseInt(idVal[1]) + 1;
			this.setProperty('Id', ("eventchartkb-" + idNumber));
			id = this.getProperty('Id');
			elem = document.getElementById('eventchartkb'+id);		
		}
	};

	this.renderHtml = function () {
		this.updateEventchartElementId();
		return 	'<div class="widget-content widget-eventchartkb">' +
					'<p id="eventchartkb'+ this.getProperty('Id')+ '"></p>' +
				'</div>';
	};

	this.afterRender = function () {
		var parent = $("#eventchartkb" + this.getProperty('Id'));
		if (this.properties.ResponsiveLayout) {
			pWidth = parent.width();
		}
		valueElem = this.jqElement.find('.eventchartkb');
		valueElem.text('Event Chart KB');
	};

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		if (updatePropertyInfo.TargetProperty === 'Data') {
			if(updatePropertyInfo.ActualDataRows.length >0){
				this.collectData(updatePropertyInfo);
				dataset = this.buildDataset();
			}
		} else if (updatePropertyInfo.TargetProperty === 'Ticks'){
			// DO Something
			//console.log(this.getProperty('Ticks'));
		} else if (updatePropertyInfo.TargetProperty === 'StartDateTime'){
			console.log(updatePropertyInfo.RawSinglePropertyValue);
			startDate = updatePropertyInfo.RawSinglePropertyValue;
			dataset = this.buildDataset();
		} else if (updatePropertyInfo.TargetProperty === 'EndDateTime'){
			console.log(updatePropertyInfo.RawSinglePropertyValue);
			endDate = updatePropertyInfo.RawSinglePropertyValue;
			dataset = this.buildDataset();
		}
		this.drawChart(dataset);
	};

	this.collectData = function (dataSource) {
		rawData = [];
		rawData = dataSource.ActualDataRows;
	};

	this.setIncludes = function(set, element){
		for(var i=0; i<set.length; i++){
			if(set[i] === element)
				return true;
		}
		return false;
	};

	this.buildDataset = function(){
		uniqueCategories = [];
		timeFieldName = this.getProperty('XAxisField');
		eventFieldName = this.getProperty('YAxisField');

		for(var i=0; i<rawData.length; i++){
			//NOT SUPPORTED IN IE
			// if(!uniqueCategories.includes(rawData[i]['event'])){
			// 	uniqueCategories.push(rawData[i]['event']);
			// 	//console.log(uniqueCategories);
			// 	//TODO: make it more dynamic!
			// }
			if(!this.setIncludes(uniqueCategories, rawData[i][eventFieldName]))
				uniqueCategories.push(rawData[i][eventFieldName]);
		}

		var categories = [];
		for(var i =0; i<uniqueCategories.length; i++){
			categories[uniqueCategories[i]] = new Object();
			categories[uniqueCategories[i]].color = this.processDataStyle(uniqueCategories[i], i);
		}

		if(startDate !== undefined || endDate !== undefined){
			var length = categories.length;
			categories['Data Not Available'] = new Object();
			categories['Data Not Available'].color = TW.getStyleFromStyleDefinition('Start/EndDateTimeBlockStyle').backgroundColor;
		}

		var data = [];

		if(startDate !== undefined){
			var datapoint = [];
			datapoint.push(startDate);
			datapoint.push("Data Not Available");
			datapoint.push(rawData[0][timeFieldName]);
			datapoint.push(0);
			data.push(datapoint);
		}

		for(var i=0; i<rawData.length-1; i++){
			var datapoint = [];
			datapoint.push(rawData[i][timeFieldName]);
			datapoint.push(rawData[i][eventFieldName]);
			datapoint.push(rawData[i+1][timeFieldName]);
			datapoint.push(0);
			data.push(datapoint);
		}

		if(endDate !== undefined){
			var datapoint = [];
			datapoint.push(rawData[rawData.length-1][timeFieldName]);
			datapoint.push("Data Not Available");
			datapoint.push(endDate);
			datapoint.push(0);
			data.push(datapoint);
		}


		var dataset = [];
		dataset['categories'] = categories;
		dataset['data'] = data;
		console.log(dataset);
		return dataset;
		
	};

	this.processDataStyle = function(seriesName, seriesNumber){
		var eventDataFormat = this.getProperty('EventDataFormat');
		var style;
		if(eventDataFormat){
			// console.log("Series Name: " + seriesName);	
			// console.log(eventDataFormat);			
			for (var i = 0; i < eventDataFormat.StateFormats.length; i++) {
				if(seriesName === eventDataFormat.StateFormats[i].value){
					style = TW.getStyleFromStyleDefinition(eventDataFormat.StateFormats[i].state);	
				}				
			}
			if(!style){
				style = TW.getStyleFromStyleDefinition('DefaultChartStyle'+(seriesNumber+1));				
			}
		} else if (TW.getStyleFromStyleDefinition(this.getProperty('SeriesStyle')+seriesNumber)){
			style = TW.getStyleFromStyleDefinition(this.getProperty('SeriesStyle'+(seriesNumber+1)));
		} else {
			style = TW.getStyleFromStyleDefinition('DefaultChartStyle'+(seriesNumber+1));
		}
		return style.backgroundColor;		
	};

	this.drawChart = function(dataset){
		var _dataset = [];
		_dataset.push(dataset);
		var chart = visavailChart()
				.width(pWidth)
				.height(this.getProperty('Height'))
				.setBarHeight(this.getProperty('BarHeight'))
				.labelBottom(this.getProperty('Label'))
				.drawTitle(this.getTitle())
				.drawSubTitle(this.getSubTitle())				
				.setTicksFormat(this.getProperty('TicksFormat'))
				.setTicks(this.getProperty('Ticks'))
				.setID("#eventchartkb"+ this.getProperty('Id'));

		
		d3.select("#eventchartkb"+ this.getProperty('Id')).select('svg').remove();		
		d3.select("#eventchartkb"+ this.getProperty('Id'))
				.datum(_dataset)
				.call(chart);
	};

	this.getTitle = function(){
		if(this.getProperty('HasTitle'))
			return this.getProperty('Title');
		else
			return 0;
	};

	this.getSubTitle = function(){
		if(this.getProperty('HasSubTitle'))
			return this.getProperty('SubTitleFormat');
		else
			return 0;
	}
};