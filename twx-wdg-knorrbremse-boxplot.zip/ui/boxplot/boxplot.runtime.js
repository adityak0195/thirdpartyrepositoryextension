TW.Runtime.Widgets.boxplot = function () {

	var valueElem;
	var numberOfSeries = 0;
	var seriesLabelsArr = [];
	var seriesColorsArr = [];
	var seriesDataColumnNamesArr = [];
	var rawData = [];
	var pWidth = this.getProperty('Width');
	var pHeight = this.getProperty('Height');
	var bordeWidth = 0;

	this.updateBoxplotElementId = function () {
		var id = this.getProperty('Id');
		var elem = document.getElementById(id);
		while (elem != null) {
			var idVal = id.split("-");
			var idNumber = parseInt(idVal[1]) + 1;
			this.setProperty('Id', ("boxplot-" + idNumber));
			id = this.getProperty('Id');
			elem = document.getElementById(id);		
		}
	};

	this.renderHtml = function () {
		this.updateBoxplotElementId();
		return '<div class="widget-content widget-boxplot">' +
			'<div id="' + this.getProperty('Id') + '" ' +
			this.renderFrame()
			+ '></div>';
	};

	this.afterRender = function () {
		var parent = $("#" + this.getProperty('Id')).parent().parent().parent();
		if (this.properties.ResponsiveLayout) {
			pWidth = parent.width();
			pHeight = parent.height();
		}
		valueElem = this.jqElement.find('.widget-boxplot-title');
		valueElem.text(this.getProperty('Title'));
	};

	this.updateProperty = function (updatePropertyInfo) {
		if (updatePropertyInfo.TargetProperty === 'Title') {
			valueElem.text(updatePropertyInfo.SinglePropertyValue);
			this.setProperty('Title', updatePropertyInfo.SinglePropertyValue);
		} else if (updatePropertyInfo.TargetProperty === 'Data') {
			this.collectSeriesData(updatePropertyInfo);
			numberOfSeries = Number(this.getProperty('NumberOfSeries'));
			this.collectSeriesLabels(numberOfSeries);
			this.collectSeriesColors(numberOfSeries);
			this.collectSeriesDataColumnNames(numberOfSeries);
		}
		if (rawData.length > 0 && numberOfSeries > 0) {
			this.drawPlot(numberOfSeries);
		}
	};

	this.collectSeriesLabels = function (numberOfSeries) {
		seriesLabelsArr = [];
		for (var i = 1; i <= numberOfSeries; i++) {
			seriesLabelsArr.push(this.getProperty('SeriesLabel' + i));
		}
	};

	this.collectSeriesDataColumnNames = function (numberOfSeries) {
		seriesDataColumnNamesArr = [];
		for (var i = 1; i <= numberOfSeries; i++) {
			seriesDataColumnNamesArr.push(this.getProperty('SeriesDataValueField' + i));
		}
	};

	this.collectSeriesColors = function (numberOfSeries) {
		seriesColorsArr = [];
		for (var i = 1; i <= numberOfSeries; i++) {
			var style = TW.getStyleFromStyleDefinition(this.getProperty('SeriesStyle' + i));
			seriesColorsArr.push(style);
		}
	};

	this.collectSeriesData = function (dataSource) {
		rawData = [];
		rawData = dataSource.ActualDataRows;
	};

	this.parseDataToSeries = function (seriesNumber) {
		var seriesData = [];
		for (var i = 0; i < rawData.length; i++) {
			seriesData.push(rawData[i][seriesDataColumnNamesArr[seriesNumber - 1]]);
		}
		return seriesData;
	};

	this.drawPlot = function (numberOfSeries) {
		var y0 = [0.1, 0.2, 0.5, 0.6, 0.65, 0.7]; //dummy sdata
		var traces = [];

		for (var i = 1; i <= numberOfSeries; i++) {
			var trace = {};
			var seriesData = this.parseDataToSeries(i);
			if (this.getProperty('Orientation') === 'vertical') {
				trace.y = seriesData;
			} else {
				trace.x = seriesData;
			}
			trace.type = 'box';
			trace.name = seriesLabelsArr[i - 1];
			trace.marker = {};
			trace.marker.color = this.hexToRGB(seriesColorsArr[i - 1].foregroundColor);
			trace.marker.outliercolor = this.hexToRGB(seriesColorsArr[i - 1].backgroundColor);
			if (this.getProperty('BoxplotStyling') === 'sd') {
				trace.boxmean = 'sd';
			} else {
				var value = this.getProperty('BoxplotStyling');
				trace.boxmean = JSON.parse(value);
			}
			traces.push(trace);
		}

		var layout = {
			title: this.getProperty('Title'),
			showlegend: this.getProperty('ShowLegend'),
			autosize: false,
			width: pWidth - 2 * bordeWidth - 4,
			height: pHeight - 2 * bordeWidth - 4,
			margin: {
				l: 30,
				r: 30,
				b: 40,
				t: 80
			},
		};

		Plotly.newPlot(this.getProperty('Id'), traces, layout);
	};

	this.resize = function (width, height) {
		if (this.properties.ResponsiveLayout) {
			pWidth = width;
			pHeight = height;
			this.drawPlot(numberOfSeries);
		}
	};

	this.hexToRGB = function (hex) {
		return 'rgb(' + (hex = hex.replace('#', '')).match(new RegExp('(.{' + hex.length / 3 + '})', 'g')).map(function (l) { return parseInt(hex.length % 2 ? l + l : l, 16) }) + ')';
	};

	this.renderFrame = function () {
		var style = TW.getStyleFromStyleDefinition(this.getProperty('FrameStyle'));
		var borderStyle = style.lineStyle;
		bordeWidth = style.lineThickness;
		var borderColor = style.foregroundColor;
		return 'style="' +
			'border-style:' + borderStyle +
			';border-width:' + bordeWidth +
			';border-color:' + borderColor + '"';
	};
};