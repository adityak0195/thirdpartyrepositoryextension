TW.IDE.Widgets.eventchartkb = function () {

	this.DEFAULT_INPUTS = 4;
	this.MAX_INPUTS = 40;

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/twx-wdg-knorrbremse-eventchartkb/ui/eventchartkb/eventchartkb.ide.png'";
	};

	this.widgetProperties = function () {
		var properties = {
			'name': 'Event Chart KB',
			'description': '',
			'category': ['Common'],
            'supportsAutoResize': true,
			'supportsTooltip': true,			
			'properties': {
				'HasTitle':{
					'isEditable': true,
                    'defaultValue': true,
					'baseType': 'BOOLEAN',
				},
				'Title':{
					'isBindingTarget': true,
                    'isEditable': true,
                    'defaultValue': 'Event Chart KB',
					'baseType': 'STRING',
					'isVisible': true										
				},
				'HasSubTitle':{
					'isEditable': true,
                    'defaultValue': true,
					'baseType': 'BOOLEAN',
				},
				'SubTitleFormat':{
					'isBindingTarget': true,
					'isEditable': true,
					'defaultValue': 'DD MMMM YYYY HH:mm:ss',
					'baseType': 'STRING',
					'isVisible': true										
				},
				'StartDateTime': {
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'DATETIME'
				},
				'EndDateTime': {
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'DATETIME'
				},
				'Start/EndDateTimeBlockStyle': {
                    'isEditable': true,
					'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultChartStyle6'
				},
				'Data': {
                    'isBindingTarget': true,
                    'isEditable': false,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
				},
				'XAxisField':{
					'baseType': 'FIELDNAME',
					'isBindingTarget':false,
					'sourcePropertyName': 'Data',
					'baseTypeRestriction': 'DATETIME',
					'isVisible': true, 
				},
				'YAxisField':{
					'baseType': 'FIELDNAME',
					'isBindingTarget':false,
					'sourcePropertyName': 'Data',
					'isVisible': true, 
				},
				'NumberOfSeries': {
                    'baseType': 'NUMBER',
                    'defaultValue': this.DEFAULT_INPUTS
				},
				// 'LabelBottom':{
                //     'defaultValue': false,
				// 	'baseType': 'BOOLEAN',
				// },
				'Label': {
                    'baseType': 'STRING',
                    'isVisible': true,
                    'defaultValue': 'bottom',                 
                    'selectOptions': [
                        { value: 'bottom', 	text: 'Bottom' },
						{ value: 'top', 	text: 'Top' },
                        { value: 'none', 	text: 'None' }                      
                    ]
                },
				'BarHeight': {
					'description' : 'Data bar height.',
					'baseType': 'INTEGER',
					'defaultValue': 18				
                },
				'EventDataFormat': {
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data',
                    'isVisible': true
				},
				'TicksFormat': {
					'description' : 'empty: automatic',
					'baseType': 'STRING',					
				},
				'Ticks': {
					'description' : 'See doc to set up value properly!',
					'baseType': 'INTEGER',
					'defaultValue': 10,					
					'isVisible': true					
                },
				'Width': {
                    'defaultValue': 480,
                },
                'Height': {
					'defaultValue': 82,					
					'isEditable': false,					
				},				
			}
		}

		var seriesNumber;
        for (seriesNumber = 1; seriesNumber <= this.DEFAULT_INPUTS; seriesNumber++) {
			var no = seriesNumber;
			if(seriesNumber > 20) no = seriesNumber - 20;
            var seriesStyle = {
                'baseType': 'STYLEDEFINITION',
				'isVisible': true,
				'defaultValue': 'DefaultChartStyle'+no
			};		
			properties.properties['SeriesStyle' + seriesNumber] = seriesStyle;					
        }

        for (seriesNumber = this.DEFAULT_INPUTS + 1; seriesNumber <= this.MAX_INPUTS; seriesNumber++) {
			var no = seriesNumber;
			if(seriesNumber > 20) no = seriesNumber - 20;
            var seriesStyle = {
                'baseType': 'STYLEDEFINITION',
				'isVisible': false,
				'defaultValue': 'DefaultChartStyle'+no		
			};
			properties.properties['SeriesStyle' + seriesNumber] = seriesStyle;
		}
		return properties;
	};

	this.afterLoad = function () {
		this.setTitleProperty(this.getProperty('HasTitle'));
		this.setSeriesNumber(this.getProperty('NumberOfSeries'));
		this.setProperty('Height', this.calcHeight());		
    };

	this.beforeSetProperty = function (name, value) {
        if(name === 'NumberOfSeries') {
			this.setSeriesNumber(value);
		} else if(name === 'HasTitle'){
			this.setTitleProperty(value);
			this.setProperty('Height', this.calcHeight());					
		} else if(name === 'HasSubTitle'){
			this.setSubTitleProperty(value);
			this.setProperty('Height', this.calcHeight());						
		}else if(name === 'BarHeight'){
			this.setProperty('Height', this.calcHeight());					
		} else if(name === 'Label'){
			this.setProperty('Height', this.calcHeight());								
		}
    };

	this.afterSetProperty = function (name, value) {
		if(name === 'NumberOfSeries') {
			this.setSeriesNumber(value);
		} else if(name === 'HasTitle'){
			this.setTitleProperty(value);
			this.setProperty('Height', this.calcHeight());
		} else if(name === 'HasSubTitle'){
			this.setSubTitleProperty(value);
			this.setProperty('Height', this.calcHeight());						
		} else if(name === 'BarHeight'){
			this.setProperty('Height', this.calcHeight());					
		} else if(name === 'Label'){
			this.setProperty('Height', this.calcHeight());								
		}
		this.updatedProperties();		
		return true;
	};

	this.setTitleProperty = function(value){
		var allWidgetProps = this.allWidgetProperties();				
		allWidgetProps.properties['Title'].isVisible = value;
	};

	this.setSubTitleProperty = function(value){
		var allWidgetProps = this.allWidgetProperties();				
		allWidgetProps.properties['SubTitleFormat'].isVisible = value;
	};

	this.setSeriesNumber = function(value){
		var allWidgetProps = this.allWidgetProperties();				
		var seriesNumber;
		
		for (seriesNumber = 1; seriesNumber <= value; seriesNumber++) {
			var no = seriesNumber;
			if(seriesNumber > 20) no = seriesNumber - 20;
			allWidgetProps.properties['SeriesStyle' + seriesNumber].isVisible = true;
			allWidgetProps.properties['SeriesStyle' + seriesNumber].baseType = 'STYLEDEFINITION';
			allWidgetProps.properties['SeriesStyle' + seriesNumber].defaultValue = "DefaultChartStyle" + no;
		}

		for (seriesNumber = value + 1; seriesNumber <= this.MAX_INPUTS; seriesNumber++) {
			allWidgetProps.properties['SeriesStyle' + seriesNumber].isVisible = false;
		}
	};

	this.calcHeight = function(){
		var height = 0;
		var barHeight = this.getProperty("BarHeight");
		var label = this.getProperty("Label");
		var hasTitle = this.getProperty("HasTitle");
		var hasSubTitle = this.getProperty("HasSubTitle");
		
		height += barHeight;
		height += 20; //Ticks
		if(hasTitle) height += 20;
		if(hasSubTitle)	height += 10;		
		if(label != 'none')	height += 14;
		return height;
	};

	this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-eventchartkb"><table height="100%" width="100%"><tr><td valign="middle" align="center"><span>'+"Event Chart KB"+'</span></td></tr></table></div>';
        return html;
    };

	this.afterRender = function () {
		valueElem = this.jqElement.find('.eventchartkb');
		valueElem.text('Event Chart KB');
	};
};